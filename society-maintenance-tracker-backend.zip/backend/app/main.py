from fastapi import FastAPI

from app.routers import admin, auth, complaints, notices

app = FastAPI(
    title="Society Maintenance Tracker",
    version="1.0.0",
)

app.include_router(auth.router, prefix="/api/v1")
app.include_router(complaints.router, prefix="/api/v1")
app.include_router(notices.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")
app.include_router(admin.settings_router, prefix="/api/v1")
app.include_router(admin.dashboard_router, prefix="/api/v1")
app.include_router(admin.admin_notices_router, prefix="/api/v1")


@app.get("/health")
def health_check():
    return {
        "status": "ok"
    }
